# Architectural Decisions Log

This document records non-trivial decisions made during autonomous development. Each entry:

```
## YYYY-MM-DD — Title
Context: what required a decision
Decision: what was chosen
Alternatives considered: what was rejected and why
Consequences: trade-offs accepted
```

---

(Claude Code: append new entries below as you make decisions during the build.)
